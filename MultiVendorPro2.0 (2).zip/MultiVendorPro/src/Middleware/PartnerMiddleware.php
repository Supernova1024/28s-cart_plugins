<?php
namespace App\Plugins\Other\MultiVendorPro\Middleware;
use Closure;
class PartnerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!sc_store_is_partner(session('adminStoreId'))) {
            return redirect()->route('vendor_admin.deny')->with(['url' => $request->url(), 'method' => $request->method()]);
        }
        return $next($request);
    }
}
