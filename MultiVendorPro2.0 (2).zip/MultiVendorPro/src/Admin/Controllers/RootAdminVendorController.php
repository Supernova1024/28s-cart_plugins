<?php
namespace App\Plugins\Other\MultiVendorPro\Admin\Controllers;

use App\Http\Controllers\RootAdminController;
use App\Plugins\Other\MultiVendorPro\AppConfig;
use App\Http\Controllers\Controller;

class RootAdminVendorController extends Controller
{
    public $plugin;
    public $templatePathAdmin;
    public function __construct()
    {
        $this->plugin = new AppConfig;
        $this->templatePathAdmin = (new AppConfig)->pathPlugin.'::Admin.';
    }
}
