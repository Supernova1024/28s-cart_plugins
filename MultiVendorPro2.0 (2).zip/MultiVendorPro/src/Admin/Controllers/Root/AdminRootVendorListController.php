<?php
namespace App\Plugins\Other\MultiVendorPro\Admin\Controllers\Root;

use SCart\Core\Admin\Models\AdminStore;
use SCart\Core\Front\Models\ShopLanguage;
use SCart\Core\Front\Models\ShopCurrency;
use SCart\Core\Front\Models\ShopTax;
use SCart\Core\Admin\Models\AdminConfig;
use Validator;
use Illuminate\Support\Facades\Artisan;
use DB;
use App\Plugins\Other\MultiVendorPro\Admin\Controllers\RootAdminVendorController;

class AdminRootVendorListController extends RootAdminVendorController
{
    public $templates, $currencies, $languages, $timezones;

    public function __construct()
    {
        parent::__construct();
        $allTemplate = sc_get_all_template();
        $templates = [];
        foreach ($allTemplate as $key => $template) {
            $templates[$key] = empty($template['config']['name']) ? $key : $template['config']['name'];
        }
        foreach (timezone_identifiers_list() as $key => $value) {
            $timezones[$value] = $value;
        }
        $this->templates = $templates;
        $this->currencies = ShopCurrency::getCodeActive();
        $this->languages = ShopLanguage::getListActive();
        $this->timezones = $timezones;

    }
    
    public function index()
    {
        $data = [
            'title' => sc_language_render('store.admin.list'),
            'subTitle' => sc_language_render($this->plugin->pathPlugin.'::lang.admin.help'),
            'icon' => 'fa fa-indent',        
        ];
        $stories = AdminStore::with('descriptions')
            ->where('id', '<>', 1)
            ->get()
            ->keyBy('id');
        $data['stories'] = $stories;
        $data['templates'] = $this->templates;
        $data['timezones'] = $this->timezones;
        $data['languages'] = $this->languages;
        $data['currencies'] =$this->currencies;
        $data['pathPlugin'] =$this->plugin->pathPlugin;

        $data['urlDeleteItem'] = sc_route('admin_MultiVendorPro.delete');
        return view($this->plugin->pathPlugin.'::Admin.screen.root.store_list')
            ->with($data);
    }


    /**
     * Form create new store in admin
     * @return [type] [description]
     */
    public function create()
    {
        $data = [
            'title' => sc_language_render('store.admin.add_new_title'),
            'subTitle' => '',
            'title_description' => sc_language_render('store.admin.add_new_des'),
            'icon' => 'fa fa-plus',
            'store' => [],
            'languages' => $this->languages,
            'url_action' => sc_route('admin_MultiVendorPro.create'),
            'templates' => $this->templates
        ];

        $data['timezones'] = $this->timezones;
        $data['currencies'] =$this->currencies;

        return view($this->plugin->pathPlugin.'::Admin.screen.root.store_add')
            ->with($data);
    }

    /*
    * Post create new order in admin
    * @return [type] [description]
    */
    public function postCreate()
    {
        $data = request()->all();
        $data['domain'] = sc_process_domain_store($data['domain']);
        $data['code'] = sc_word_limit(sc_word_format_url($data['code']), 20);
        $validator = Validator::make($data, [
            'descriptions.*.title' => 'required|string|max:200',
            'descriptions.*.keyword' => 'nullable|string|max:200',
            'descriptions.*.description' => 'nullable|string|max:300',
            'timezone' => 'required',
            'code'     => 'required|string|max:20|unique:"'.AdminStore::class.'",code',
            'language' => 'required',
            'currency' => 'required',
            'template' => 'required',
            ], [
                'descriptions.*.title.required' => sc_language_render('validation.required', ['attribute' => sc_language_render('store.title')]),
                'descriptions.*.keyword.required' => sc_language_render('validation.required', ['attribute' => sc_language_render('store.keyword')]),
                'descriptions.*.description.required' => sc_language_render('validation.required', ['attribute' => sc_language_render('store.description')]),
            ]
        );
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput($data);
        }
        $dataInsert = [
            'logo'        => $data['logo'],
            'phone'       => $data['phone'],
            'long_phone'  => $data['long_phone'],
            'email'       => $data['email'],
            'time_active' => $data['time_active'],
            'address'     => $data['address'],
            'office'      => $data['office'],
            'timezone'    => $data['timezone'],
            'language'    => $data['language'],
            'currency'    => $data['currency'],
            'template'    => $data['template'],
            'domain'      => $data['domain'],
            'code'        => $data['code'],
            'status'      => empty($data['status']) ? 0 : 1,
        ];
        try {
        //Create new store
        DB::connection(SC_CONNECTION)
            ->transaction(function () use($dataInsert, $data) {
                $store = AdminStore::create($dataInsert);
                $dataDes = [];
                $languages = ShopLanguage::getListActive();
                foreach ($languages as $code => $value) {
                    $dataDes[] = [
                        'store_id'    => $store->id,
                        'lang'        => $code,
                        'title'       => $data['descriptions'][$code]['title'],
                        'keyword'     => $data['descriptions'][$code]['keyword'],
                        'description' => $data['descriptions'][$code]['description'],
                        'maintain_content' => '<center><img src="/images/maintenance.png" />
                        <h3><span style="color:#e74c3c;"><strong>Sorry! We are currently doing site maintenance!</strong></span></h3>
                        </center>'
                    ];
                }
                AdminStore::insertDescription($dataDes);

                //Add config default for new store
                session(['lastStoreId' => $store->id]);
                Artisan::call('db:seed', [
                    '--class' => 'DataStoreSeeder',
                    '--force' => true
                ]);
                session()->forget('lastStoreId');
                
            }, 2);
        }catch(\Throwable $e) {
            return redirect()->back()->withInput()->with('error', $e->getMessage());
        }
        return redirect()->route('admin_MultiVendorPro.index')->with('success', sc_language_render('action.create_success'));

    }

    public function config($id) {
        if ($id == SC_ID_ROOT) {
            return redirect()->route('admin_store.index');
        }
        $store = AdminStore::find($id);
        if (!$store) {
            $data = [
                'title' => sc_language_render('store.admin.config_store', ['id' => $id]),
                'subTitle' => '',
                'icon' => 'fas fa-cogs',
                'dataNotFound' => 1       
            ];
            return view($this->templatePathAdmin.'screen.store_config')
            ->with($data);
        }

        $breadcrumb['url'] = sc_route('admin_MultiVendorPro.index');
        $breadcrumb['name'] = sc_language_render('store.admin.list');
        
        $data = [
            'title' => sc_language_render('store.admin.config_store', ['id' => $id]),
            'subTitle' => '',
            'icon' => 'fas fa-cogs',        
        ];
        $stories = AdminStore::getListAll();
        $data['store'] = $stories[$id] ?? [];

        // Customer config
        $dataCustomerConfig = [
            'code' => 'customer_config_attribute',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $customerConfigs = AdminConfig::getListConfigByCode($dataCustomerConfig);
        
        $dataCustomerConfigRequired = [
            'code' => 'customer_config_attribute_required',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $customerConfigsRequired = AdminConfig::getListConfigByCode($dataCustomerConfigRequired);
        //End customer

        //Product config
        $taxs = ShopTax::pluck('name', 'id')->toArray();
        $taxs[0] = sc_language_render('tax.admin.non_tax');

        $productConfigQuery = [
            'code' => 'product_config',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $productConfig = AdminConfig::getListConfigByCode($productConfigQuery);

        $productConfigAttributeQuery = [
            'code' => 'product_config_attribute',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $productConfigAttribute = AdminConfig::getListConfigByCode($productConfigAttributeQuery);

        $productConfigAttributeRequiredQuery = [
            'code' => 'product_config_attribute_required',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $productConfigAttributeRequired = AdminConfig::getListConfigByCode($productConfigAttributeRequiredQuery);

        $orderConfigQuery = [
            'code' => 'order_config',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $orderConfig = AdminConfig::getListConfigByCode($orderConfigQuery);

        $configDisplayQuery = [
            'code' => 'display_config',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $configDisplay = AdminConfig::getListConfigByCode($configDisplayQuery);

        $configCaptchaQuery = [
            'code' => 'captcha_config',
            'storeId' => $id,
            'keyBy' => 'key',
        ];
        $configCaptcha = AdminConfig::getListConfigByCode($configCaptchaQuery);

        $emailConfigQuery = [
            'code'    => ['smtp_config', 'email_action'],
            'storeId' => $id,
            'groupBy' => 'code',
            'sort'    => 'asc',
        ];
        $emailConfig = AdminConfig::getListConfigByCode($emailConfigQuery);
        $data['smtp_method'] = ['' => 'None Secirity', 'TLS' => 'TLS', 'SSL' => 'SSL'];
        $data['captcha_page'] = [
            'register' => sc_language_render('captcha.captcha_page_register'), 
            'forgot'   => sc_language_render('captcha.captcha_page_forgot_password'), 
            'checkout' => sc_language_render('captcha.captcha_page_checkout'), 
            'contact'  => sc_language_render('captcha.captcha_page_contact'), 
        ];
        //End email
        $data['customerConfigs']                = $customerConfigs;
        $data['customerConfigsRequired']        = $customerConfigsRequired;
        $data['productConfig']                  = $productConfig;
        $data['productConfigAttribute']         = $productConfigAttribute;
        $data['productConfigAttributeRequired'] = $productConfigAttributeRequired;
        $data['pluginCaptchaInstalled']         = sc_get_plugin_captcha_installed();
        $data['taxs']                           = $taxs;
        $data['configDisplay']                  = $configDisplay;
        $data['orderConfig']                    = $orderConfig;
        $data['configCaptcha']                  = $configCaptcha;
        $data['emailConfig']                    = $emailConfig;
        $data['templates']                      = $this->templates;
        $data['timezones']                      = $this->timezones;
        $data['languages']                      = $this->languages;
        $data['currencies']                     = $this->currencies;
        $data['storeId']                        = $id;
        $data['pathPlugin']                     = $this->plugin->pathPlugin;
        $data['breadcrumb']                     = $breadcrumb;
        $data['urlUpdateConfig']                = sc_route('admin_config.update');
        $data['urlUpdateStore']                 = sc_route('admin_store.update');
        return view($this->plugin->pathPlugin.'::Admin.screen.root.store_config')
        ->with($data);
    }

    /*
    Delete list item
    Need mothod destroy to boot deleting in model
    */
    public function delete()
    {
        if (!request()->ajax()) {
            return response()->json(['error' => 1, 'msg' => 'Method not allow!']);
        } else {
            $id = request('id');
            if (config('app.storeId') == $id) {
                return response()->json(['error' => 1, 'msg' => sc_language_render('store.cannot_delete')]);
            }
            if ($id != SC_ID_ROOT) {
                AdminStore::destroy($id);
                Adminconfig::where('store_id', $id)->delete();
            }
            return response()->json(['error' => 0, 'msg' => 'Remove store success!']);
        }
    }

    /**
     * Store code
     *
     * @return  [type]  [return description]
     */
    public function getStoreCode() {
        $code = sc_token(8);
        if (AdminStore::where('code', $code)->first()) {
            $code = sc_token(8);
        }
        return $code;
    }

}
