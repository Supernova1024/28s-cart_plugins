<!--ckeditor-->
<script src="{{ sc_file('vendor/ckeditor/ckeditor.js') }}"></script>
<script src="{{ sc_file('vendor/ckeditor/adapters/jquery.js') }}"></script>