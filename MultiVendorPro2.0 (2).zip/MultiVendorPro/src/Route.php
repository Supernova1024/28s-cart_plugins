<?php

/**
 * Admin mamanager multi-vendor
 */
Route::group(
    [
        'prefix' => SC_ADMIN_PREFIX.'/MultiVendorPro',
        'middleware' => SC_ADMIN_MIDDLEWARE,
        'namespace' => 'App\Plugins\Other\MultiVendorPro\Admin\Controllers\Root',
    ], 
    function () {
        //Store
        Route::group(['prefix' => 'store'], function () {
            Route::get('/', 'AdminRootVendorListController@index')
            ->name('admin_MultiVendorPro.index');
            Route::get('/create', 'AdminRootVendorListController@create')
            ->name('admin_MultiVendorPro.create');
            Route::post('/create', 'AdminRootVendorListController@postCreate');
            Route::post('/delete', 'AdminRootVendorListController@delete')
            ->name('admin_MultiVendorPro.delete');
            Route::get('/config/{id}', 'AdminRootVendorListController@config')
            ->name('admin_MultiVendorPro.config');
        });

        //Vendor
        Route::group(['prefix' => 'vendor'], function () {
            Route::get('/', 'AdminRootVendorUserListController@index')
            ->name('admin_MultiVendorProUser.index');
            Route::get('/create', 'AdminRootVendorUserListController@create');
            Route::post('/create', 'AdminRootVendorUserListController@postCreate')->name('admin_MultiVendorProUser.create');
            Route::get('/edit/{id}', 'AdminRootVendorUserListController@edit')->name('admin_MultiVendorProUser.edit');
            Route::post('/edit/{id}', 'AdminRootVendorUserListController@postEdit');
            Route::post('/delete', 'AdminRootVendorUserListController@deleteList')->name('admin_MultiVendorProUser.delete');
        }); 
    }
);

if (sc_config('MultiVendorPro') && sc_get_domain_root() == sc_process_domain_store(url('/'))) {
    /**
     * vendor manager
     * Only allow on domain root
     */

    Route::group(
        [
            'prefix' => 'vendor_admin',
            'middleware' => ['web', 'vendor'],
            'namespace' => 'App\Plugins\Other\MultiVendorPro\Admin\Controllers',
        ], 
        function () {
            Route::get('register', 'Auth\RegisterController@showRegister')->name('vendor.register');
            Route::post('register', 'Auth\RegisterController@postRegister')->name('vendor.register');
            Route::get('forgot', 'Auth\ForgotPasswordController@getForgot')->name('vendor.forgot');
            Route::post('forgot', 'Auth\ForgotPasswordController@sendRepostForgotsetLinkEmail')->name('vendor.forgot');
            Route::get('password/reset/{token}', 'Auth\ResetPasswordController@formResetPassword')->name('vendor.password_reset');
            Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('vendor.post_password_reset');
            Route::get('setting', 'Auth\LoginController@getSetting')->name('vendor.setting');
            Route::post('setting', 'Auth\LoginController@putSetting')->name('vendor.setting');
            Route::get('login', 'Auth\LoginController@getLogin')->name('vendor.login');
            Route::post('login', 'Auth\LoginController@postLogin')->name('vendor.login');
            Route::get('logout', 'Auth\LoginController@getLogout')->name('vendor.logout');
        }
    );
    
    Route::group(
        [
            'prefix' => 'vendor_admin',
            'middleware' => ['web', 'vendor'],
            'namespace' => 'App\Plugins\Other\MultiVendorPro\Admin\Controllers\Vendor',
        ], 
        function () {

            //Language
            Route::get('locale/{code}', function ($code) {
                session(['locale' => $code]);
                return back();
            })->name('admin.locale');

            Route::get('deny', 'DashboardVendorController@deny')->name('vendor_admin.deny');
            Route::get('data_not_found', 'DashboardVendorController@dataNotFound')->name('vendor_admin.data_not_found');
            Route::get('deny_single', 'DashboardVendorController@denySingle')->name('vendor_admin.deny_single');
            Route::get('account_inactive', 'DashboardVendorController@accountInactive')->name('vendor_admin.account_inactive');


            Route::group(['middleware' => ['checkVendorActive', 'checkStoreExist']], function () {

                Route::get('/', 'DashboardVendorController@index')->name('vendor_admin.home');

                Route::group(['prefix' => 'uploads', 'namespace' => '\\UniSharp\\LaravelFilemanager\\Controllers\\'], function () {

                    // display main layout
                    Route::get('/', [
                        'uses' => 'LfmController@show',
                        'as' => 'unisharp.lfm.show',
                    ]);
                
                    // display integration error messages
                    Route::get('/errors', [
                        'uses' => 'LfmController@getErrors',
                        'as' => 'unisharp.lfm.getErrors',
                    ]);
                
                    // upload
                    Route::post('/upload', [
                        'uses' => 'UploadController@upload',
                        'as' => 'unisharp.lfm.upload',
                    ]);
                
                    // list images & files
                    Route::get('/jsonitems', [
                        'uses' => 'ItemsController@getItems',
                        'as' => 'unisharp.lfm.getItems',
                    ]);
                
                    Route::get('/move', [
                        'uses' => 'ItemsController@move',
                        'as' => 'unisharp.lfm.move',
                    ]);
                
                    Route::get('/domove', [
                        'uses' => 'ItemsController@domove',
                        'as' => 'unisharp.lfm.domove',
                    ]);
                
                    // folders
                    Route::get('/newfolder', [
                        'uses' => 'FolderController@getAddfolder',
                        'as' => 'unisharp.lfm.getAddfolder',
                    ]);
                
                    // list folders
                    Route::get('/folders', [
                        'uses' => 'FolderController@getFolders',
                        'as' => 'unisharp.lfm.getFolders',
                    ]);
                
                    // crop
                    Route::get('/crop', [
                        'uses' => 'CropController@getCrop',
                        'as' => 'unisharp.lfm.getCrop',
                    ]);
                    Route::get('/cropimage', [
                        'uses' => 'CropController@getCropimage',
                        'as' => 'unisharp.lfm.getCropimage',
                    ]);
                    Route::get('/cropnewimage', [
                        'uses' => 'CropController@getNewCropimage',
                        'as' => 'unisharp.lfm.getCropimage',
                    ]);
                
                    // rename
                    Route::get('/rename', [
                        'uses' => 'RenameController@getRename',
                        'as' => 'unisharp.lfm.getRename',
                    ]);
                
                    // scale/resize
                    Route::get('/resize', [
                        'uses' => 'ResizeController@getResize',
                        'as' => 'unisharp.lfm.getResize',
                    ]);
                    Route::get('/doresize', [
                        'uses' => 'ResizeController@performResize',
                        'as' => 'unisharp.lfm.performResize',
                    ]);
                
                    // download
                    Route::get('/download', [
                        'uses' => 'DownloadController@getDownload',
                        'as' => 'unisharp.lfm.getDownload',
                    ]);
                
                    // delete
                    Route::get('/delete', [
                        'uses' => 'DeleteController@getDelete',
                        'as' => 'unisharp.lfm.getDelete',
                    ]);
                });


                Route::group(['prefix' => '/order'], function () {
                        Route::get('/', 'AdminVendorOrderController@index')->name('admin_mvendor_order.index');
                        Route::get('/detail/{id}', 'AdminVendorOrderController@edit')->name('admin_mvendor_order.detail');
                        Route::post('/update', 'AdminVendorOrderController@postOrderUpdate')->name('admin_mvendor_order.update');
                    }
                );
                Route::group(['prefix' => '/category'], function () {
                        Route::get('/', 'AdminVendorCategoryController@index')->name('admin_mvendor_category.index');
                        Route::get('create', 'AdminVendorCategoryController@create')->name('admin_mvendor_category.create');
                        Route::post('/create', 'AdminVendorCategoryController@postCreate')->name('admin_mvendor_category.create');
                        Route::get('/edit/{id}', 'AdminVendorCategoryController@edit')->name('admin_mvendor_category.edit');
                        Route::post('/edit/{id}', 'AdminVendorCategoryController@postEdit')->name('admin_mvendor_category.edit');
                        Route::post('/delete', 'AdminVendorCategoryController@deleteList')->name('admin_mvendor_category.delete');
                    }
                );

                Route::group(['prefix' => 'product'], function () {
                    Route::get('/', 'AdminVendorProductController@index')->name('admin_mvendor_product.index');
                    Route::get('create', 'AdminVendorProductController@create')->name('admin_mvendor_product.create');
                    Route::get('build_create', 'AdminVendorProductController@createProductBuild')->name('admin_mvendor_product.build_create');
                    Route::get('group_create', 'AdminVendorProductController@createProductGroup')->name('admin_mvendor_product.group_create');
                    Route::post('/create', 'AdminVendorProductController@postCreate')->name('admin_mvendor_product.create');
                    Route::get('/edit/{id}', 'AdminVendorProductController@edit')->name('admin_mvendor_product.edit');
                    Route::post('/edit/{id}', 'AdminVendorProductController@postEdit')->name('admin_mvendor_product.edit');
                    Route::post('/delete', 'AdminVendorProductController@deleteList')->name('admin_mvendor_product.delete');
                    Route::get('/import', 'AdminVendorProductController@import')->name('admin_mvendor_product.import');
                    Route::post('/import', 'AdminVendorProductController@postImport')->name('admin_mvendor_product.import');
                });

                Route::group(['prefix' => 'banner'], function () {
                    Route::get('/', 'AdminVendorBannerController@index')->name('admin_mvendor_banner.index');
                    Route::get('create', 'AdminVendorBannerController@create')->name('admin_mvendor_banner.create');
                    Route::post('/create', 'AdminVendorBannerController@postCreate')->name('admin_mvendor_banner.create');
                    Route::get('/edit/{id}', 'AdminVendorBannerController@edit')->name('admin_mvendor_banner.edit');
                    Route::post('/edit/{id}', 'AdminVendorBannerController@postEdit')->name('admin_mvendor_banner.edit');
                    Route::post('/delete', 'AdminVendorBannerController@deleteList')->name('admin_mvendor_banner.delete');
                });

                Route::group(['prefix' => 'vendor_link'], function () {
                    Route::get('/', 'AdminVendorLinkController@index')->name('admin_mvendor_link.index');
                    Route::get('create', 'AdminVendorLinkController@create')->name('admin_mvendor_link.create');
                    Route::post('/create', 'AdminVendorLinkController@postCreate')->name('admin_mvendor_link.create');
                    Route::get('/edit/{id}', 'AdminVendorLinkController@edit')->name('admin_mvendor_link.edit');
                    Route::post('/edit/{id}', 'AdminVendorLinkController@postEdit')->name('admin_mvendor_link.edit');
                    Route::post('/delete', 'AdminVendorLinkController@deleteList')->name('admin_mvendor_link.delete');
                });

                Route::group(['prefix' => 'vendor_maintain', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorMaintainController@index')->name('admin_mvendor_maintain.index');
                    Route::post('/', 'AdminVendorMaintainController@postEdit');
                });
                
                Route::group(['prefix' => 'vendor_config', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorConfigController@index')->name('admin_mvendor_config.index');
                    Route::post('/update', 'AdminVendorConfigController@update')->name('admin_mvendor_config.update');
                });
                
                Route::group(['prefix' => 'vendor_block', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorBlockController@index')->name('admin_mvendor_block.index');
                    Route::get('create', 'AdminVendorBlockController@create')->name('admin_mvendor_block.create');
                    Route::post('/create', 'AdminVendorBlockController@postCreate')->name('admin_mvendor_block.create');
                    Route::get('/edit/{id}', 'AdminVendorBlockController@edit')->name('admin_mvendor_block.edit');
                    Route::post('/edit/{id}', 'AdminVendorBlockController@postEdit')->name('admin_mvendor_block.edit');
                    Route::post('/delete', 'AdminVendorBlockController@deleteList')->name('admin_mvendor_block.delete');
                });
                
                Route::group(['prefix' => 'page', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorPageController@index')->name('admin_mvendor_page.index');
                    Route::get('create', 'AdminVendorPageController@create')->name('admin_mvendor_page.create');
                    Route::post('/create', 'AdminVendorPageController@postCreate')->name('admin_mvendor_page.create');
                    Route::get('/edit/{id}', 'AdminVendorPageController@edit')->name('admin_mvendor_page.edit');
                    Route::post('/edit/{id}', 'AdminVendorPageController@postEdit')->name('admin_mvendor_page.edit');
                    Route::post('/delete', 'AdminVendorPageController@deleteList')->name('admin_mvendor_page.delete');
                });

                Route::group(['prefix' => 'news', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorNewsController@index')->name('admin_mvendor_news.index');
                    Route::get('create', 'AdminVendorNewsController@create')->name('admin_mvendor_news.create');
                    Route::post('/create', 'AdminVendorNewsController@postCreate')->name('admin_mvendor_news.create');
                    Route::get('/edit/{id}', 'AdminVendorNewsController@edit')->name('admin_mvendor_news.edit');
                    Route::post('/edit/{id}', 'AdminVendorNewsController@postEdit')->name('admin_mvendor_news.edit');
                    Route::post('/delete', 'AdminVendorNewsController@deleteList')->name('admin_mvendor_news.delete');
                });
                

                Route::group(['prefix' => 'vendor_css', 'middleware' => ['isPartner']], function () {
                    Route::get('/', 'AdminVendorCssController@index')->name('admin_mvendor_css.index');
                    Route::post('/', 'AdminVendorCssController@postEdit');
                });

                //vendor create store
                Route::group(
                    [
                        'prefix' => 'vendor_update',
                    ], 
                    function () {
                        Route::get('/', 'AdminVendorInfoController@vendorUpdate')
                            ->name('admin_mvendor_info.update');
                        Route::post('/', 'AdminVendorInfoController@vendorPostUpdate');
                    }
                );
            });           
        }
    );
}

//Front-end
if (sc_config('MultiVendorPro')) {
    // Multi vendor only active for vendor root
    if(config('app.storeId') == SC_ID_ROOT) {
        /**
         * Route shop
         */
        Route::group(
            [
                'prefix' => 'vendor',
                'namespace' => 'App\Plugins\Other\MultiVendorPro\Controllers',
            ], 
            function () {
                Route::get('/{code?}', 'FrontController@vendorDetail')->name('MultiVendorPro.detail');
            }
        );
    }

    $prefixCategoryvendor = sc_config('PREFIX_CATEGORY_VENDOR') ?? 'category-vendor';
    Route::group(
        [
            'prefix' => $prefixCategoryvendor,
            'namespace' => 'App\Plugins\Other\MultiVendorPro\Controllers',
        ], 
        function () {
            Route::get('/{alias}/s{storeId}.html', 'FrontController@categoryVendorDetail')->name('vendor_category.detail');
        }
    );
    
}