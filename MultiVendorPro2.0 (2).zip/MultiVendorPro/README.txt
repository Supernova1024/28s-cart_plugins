========= INSTALL =========
Step1:
Import plugin : https://s-cart.org/en/docs/master/how-to-install-module-extension.html#install-plugin-import
Step2:
Copy folder src/template/vendor to folder resources/views/your-teamplate/vendor
Step3:
Access to admin -> layout -> block content -> add new block :type view (choose vendor_new), position: top, page: home page
Step 4:
Access yourd-main/sc_admin/MultiVendorPro

========= FUNCTION =========
v2.0
- Admin create and management multi store
- Admin create and management vendor user
- Vendor user forgot password
- Link create vendor user
- Store type: vendor partner, vendor basic