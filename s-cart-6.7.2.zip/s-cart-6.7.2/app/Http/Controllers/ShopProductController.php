<?php
namespace App\Http\Controllers;

class ShopProductController extends \SCart\Core\Front\Controllers\ShopProductController
{
    public function __construct()
    {
        parent::__construct();
    }

}
