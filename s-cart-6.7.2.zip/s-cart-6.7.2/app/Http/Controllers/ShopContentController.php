<?php
namespace App\Http\Controllers;

class ShopContentController extends \SCart\Core\Front\Controllers\ShopContentController
{
    public function __construct()
    {
        parent::__construct();
    }

}
