<?php

namespace App\Http\Controllers\Auth;

class ForgotPasswordController extends \SCart\Core\Front\Controllers\Auth\ForgotPasswordController
{
    public function __construct()
    {
        parent::__construct();
    }
}
