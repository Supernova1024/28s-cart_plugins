<?php

namespace App\Http\Controllers\Auth;

class RegisterController extends \SCart\Core\Front\Controllers\Auth\RegisterController
{
    public function __construct()
    {
        parent::__construct();
    }
}
