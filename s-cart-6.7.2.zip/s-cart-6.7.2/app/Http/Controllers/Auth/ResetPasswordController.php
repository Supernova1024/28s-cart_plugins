<?php

namespace App\Http\Controllers\Auth;

class ResetPasswordController extends \SCart\Core\Front\Controllers\Auth\ResetPasswordController
{
    public function __construct()
    {
        parent::__construct();
    }
}
