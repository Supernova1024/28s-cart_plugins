<?php

namespace App\Http\Controllers\Auth;

class LoginController extends \SCart\Core\Front\Controllers\Auth\LoginController
{
    public function __construct()
    {
        parent::__construct();
    }
}
