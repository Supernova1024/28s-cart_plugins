<?php
namespace App\Http\Controllers;

class ShopCartController extends \SCart\Core\Front\Controllers\ShopCartController
{
    public function __construct()
    {
        parent::__construct();
    }
}
