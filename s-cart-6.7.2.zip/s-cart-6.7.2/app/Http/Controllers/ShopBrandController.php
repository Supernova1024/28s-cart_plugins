<?php
namespace App\Http\Controllers;

class ShopBrandController extends \SCart\Core\Front\Controllers\ShopBrandController
{
    public function __construct()
    {
        parent::__construct();
    }

}
