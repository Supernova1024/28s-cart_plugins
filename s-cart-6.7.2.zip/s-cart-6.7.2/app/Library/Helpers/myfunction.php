<?php
//Your functions
 
// function demoFunction() {
//     echo "Hello world!";
// }