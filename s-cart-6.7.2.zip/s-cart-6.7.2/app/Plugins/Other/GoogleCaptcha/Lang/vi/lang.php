<?php
return [
    'title'       => 'Google reCaptcha',
    'secrect_key' => 'Khóa bí mật',
    'site_key'    => 'Khóa công khai',
    'admin'      => [
        'title'          => 'GoogleCaptcha',
    ],
];
