<div class="row">
    <div class="form-group col-md-12">
        {!! sc_html_render(sc_config('BankTransfer_info')) !!}
    </div>
</div>
