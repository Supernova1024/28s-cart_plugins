<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Payment/BankTransfer');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Payment/BankTransfer');