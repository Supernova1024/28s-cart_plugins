<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Shipping/ShippingStandard');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Shipping/ShippingStandard');