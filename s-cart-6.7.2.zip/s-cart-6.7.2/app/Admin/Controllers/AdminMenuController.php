<?php
namespace App\Admin\Controllers;


class AdminMenuController extends \SCart\Core\Admin\Controllers\AdminMenuController
{
    public function __construct()
    {
        parent::__construct();
    }
}
