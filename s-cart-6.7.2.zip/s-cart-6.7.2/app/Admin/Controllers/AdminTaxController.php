<?php
namespace App\Admin\Controllers;

class AdminTaxController extends \SCart\Core\Admin\Controllers\AdminTaxController
{
    public function __construct()
    {
        parent::__construct();
    }

}
