<?php
namespace App\Admin\Controllers;

class AdminBannerController extends \SCart\Core\Admin\Controllers\AdminBannerController
{
    public function __construct()
    {
        parent::__construct();
    }
}
