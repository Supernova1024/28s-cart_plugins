<?php
namespace App\Admin\Controllers\Auth;

class RoleController extends \SCart\Core\Admin\Controllers\Auth\RoleController
{
    public function __construct()
    {
        parent::__construct();
    }

}
