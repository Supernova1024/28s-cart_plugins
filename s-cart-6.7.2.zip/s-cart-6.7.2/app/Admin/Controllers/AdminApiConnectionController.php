<?php
namespace App\Admin\Controllers;

class AdminApiConnectionController extends \SCart\Core\Admin\Controllers\AdminApiConnectionController
{
    public function __construct()
    {
        parent::__construct();
    }
}
