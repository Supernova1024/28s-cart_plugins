<?php
namespace App\Admin\Controllers;

class AdminProductPropertyController extends \SCart\Core\Admin\Controllers\AdminProductPropertyController
{
    public function __construct()
    {
        parent::__construct();
    }
}
