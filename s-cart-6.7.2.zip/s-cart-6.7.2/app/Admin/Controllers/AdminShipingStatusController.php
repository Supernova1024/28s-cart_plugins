<?php
namespace App\Admin\Controllers;

class AdminShipingStatusController extends \SCart\Core\Admin\Controllers\AdminShipingStatusController
{
    public function __construct()
    {
        parent::__construct();
    }

}
