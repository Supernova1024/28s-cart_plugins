<?php
namespace App\Admin\Controllers;

class AdminOrderStatusController extends \SCart\Core\Admin\Controllers\AdminOrderStatusController
{

    public function __construct()
    {
        parent::__construct();
    }

}
