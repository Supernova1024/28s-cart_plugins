<?php
namespace App\Admin\Controllers;

class AdminPluginsController extends \SCart\Core\Admin\Controllers\AdminPluginsController
{
    public function __construct()
    {
        parent::__construct();
    }
}
