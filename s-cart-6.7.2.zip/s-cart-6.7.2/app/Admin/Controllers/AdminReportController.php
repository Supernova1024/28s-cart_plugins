<?php
namespace App\Admin\Controllers;

class AdminReportController extends \SCart\Core\Admin\Controllers\AdminReportController
{

    public function __construct()
    {
        parent::__construct();
    }
}
