<?php
namespace App\Admin\Controllers;

class AdminLanguageController extends \SCart\Core\Admin\Controllers\AdminLanguageController
{
    public function __construct()
    {
        parent::__construct();
    }
}
