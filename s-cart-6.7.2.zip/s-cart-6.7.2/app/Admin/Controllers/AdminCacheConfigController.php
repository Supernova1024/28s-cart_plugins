<?php
namespace App\Admin\Controllers;

class AdminCacheConfigController extends \SCart\Core\Admin\Controllers\AdminCacheConfigController
{
    public function __construct()
    {
        parent::__construct();
    }
}
