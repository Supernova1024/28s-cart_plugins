<?php
namespace App\Admin\Controllers;

class AdminOrderController extends \SCart\Core\Admin\Controllers\AdminOrderController
{

    public function __construct()
    {
        parent::__construct();

    }

}
