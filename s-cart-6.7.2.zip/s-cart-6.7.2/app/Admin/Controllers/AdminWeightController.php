<?php
namespace App\Admin\Controllers;

class AdminWeightController extends \SCart\Core\Admin\Controllers\AdminWeightController
{
    public function __construct()
    {
        parent::__construct();
    }

}
