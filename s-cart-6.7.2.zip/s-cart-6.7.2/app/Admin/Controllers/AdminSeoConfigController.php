<?php
namespace App\Admin\Controllers;

class AdminSeoConfigController extends \SCart\Core\Admin\Controllers\AdminSeoConfigController
{

    public function __construct()
    {
        parent::__construct();
    }
    
}
