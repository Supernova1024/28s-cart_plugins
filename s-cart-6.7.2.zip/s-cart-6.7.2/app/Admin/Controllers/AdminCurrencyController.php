<?php
namespace App\Admin\Controllers;

class AdminCurrencyController extends \SCart\Core\Admin\Controllers\AdminCurrencyController
{
    public function __construct()
    {
        parent::__construct();
    }

}
