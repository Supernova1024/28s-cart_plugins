<?php
namespace App\Admin\Controllers;

class AdminLogController extends \SCart\Core\Admin\Controllers\AdminLogController
{

    public function __construct()
    {
        parent::__construct();
    }
    

}
