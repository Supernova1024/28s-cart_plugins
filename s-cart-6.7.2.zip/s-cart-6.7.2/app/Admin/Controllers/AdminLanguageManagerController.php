<?php
namespace App\Admin\Controllers;

class AdminLanguageManagerController extends \SCart\Core\Admin\Controllers\AdminLanguageManagerController
{
    public function __construct()
    {
        parent::__construct();
    }
}
