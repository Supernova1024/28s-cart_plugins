<?php
namespace App\Admin\Controllers;

class AdminStoreConfigController extends \SCart\Core\Admin\Controllers\AdminStoreConfigController
{
    public function __construct()
    {
        parent::__construct();
    }
}
