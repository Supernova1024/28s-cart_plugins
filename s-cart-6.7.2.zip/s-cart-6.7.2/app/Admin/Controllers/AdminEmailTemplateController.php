<?php
namespace App\Admin\Controllers;

class AdminEmailTemplateController extends \SCart\Core\Admin\Controllers\AdminEmailTemplateController
{
    public function __construct()
    {
        parent::__construct();
    }
}
