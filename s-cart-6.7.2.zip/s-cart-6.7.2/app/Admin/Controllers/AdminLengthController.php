<?php
namespace App\Admin\Controllers;

class AdminLengthController extends \SCart\Core\Admin\Controllers\AdminLengthController
{
    public function __construct()
    {
        parent::__construct();
    }
}
