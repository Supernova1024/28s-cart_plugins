<?php
namespace App\Admin\Controllers;

class AdminEnvConfigController extends \SCart\Core\Admin\Controllers\AdminEnvConfigController
{

    public function __construct()
    {
        parent::__construct();
    }
    
}
