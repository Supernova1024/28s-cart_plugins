<?php
namespace App\Admin\Controllers;

class AdminNewsController extends \SCart\Core\Admin\Controllers\AdminNewsController
{
    public function __construct()
    {
        parent::__construct();
    }
}
