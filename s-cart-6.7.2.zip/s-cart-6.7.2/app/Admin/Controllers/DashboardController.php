<?php

namespace App\Admin\Controllers;

class DashboardController extends \SCart\Core\Admin\Controllers\DashboardController
{
    public function __construct()
    {
        parent::__construct();
    }
}
