<?php
namespace App\Admin\Controllers;

class AdminStoreCssController extends \SCart\Core\Admin\Controllers\AdminStoreCssController
{
    public function __construct()
    {
        parent::__construct();
    }
}
