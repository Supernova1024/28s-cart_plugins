<?php
namespace App\Admin\Controllers;

class AdminStoreLinkController extends \SCart\Core\Admin\Controllers\AdminStoreLinkController
{
    public function __construct()
    {
        parent::__construct();
    }
    
}
