<?php
namespace App\Admin\Controllers;

class AdminTemplateOnlineController extends \SCart\Core\Admin\Controllers\AdminTemplateOnlineController
{
    public function __construct()
    {
        parent::__construct();
    }
}
