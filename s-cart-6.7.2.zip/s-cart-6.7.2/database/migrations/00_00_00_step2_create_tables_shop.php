<?php

use SCart\Core\DB\migrations\PrepareTablesShop;
class CreateTablesShop extends PrepareTablesShop
{
    //
}
