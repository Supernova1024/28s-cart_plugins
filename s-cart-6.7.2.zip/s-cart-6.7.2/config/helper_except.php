<?php
return [
    //Array of helper functions will not be defined
];