<?php
return [
    'version'     => '6.7',
    'sub-version' => '6.7.2',
    'type'        => 'basic',
    'homepage'    => 'https://s-cart.org',
    'title'       => 'Free Open Source eCommerce for Business',
];
