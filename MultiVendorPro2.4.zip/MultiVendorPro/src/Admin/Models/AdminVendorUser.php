<?php

namespace App\Plugins\Other\MultiVendorPro\Admin\Models;

use App\Plugins\Other\MultiVendorPro\Models\VendorUser;

class AdminVendorUser extends VendorUser
{
 
}
