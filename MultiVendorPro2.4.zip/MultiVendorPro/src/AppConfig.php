<?php
namespace App\Plugins\Other\MultiVendorPro;

use App\Plugins\Other\MultiVendorPro\Models\PluginModel;
use SCart\Core\Admin\Models\AdminConfig;
use SCart\Core\Admin\Models\AdminRole;
use SCart\Core\Admin\Models\AdminPermission;
use SCart\Core\Admin\Models\AdminMenu;
use SCart\Core\Front\Models\Languages;
use App\Plugins\ConfigDefault;

class AppConfig extends ConfigDefault
{
    public function __construct()
    {
        //Read config from config.json
        $config = file_get_contents(__DIR__.'/config.json');
        $config = json_decode($config, true);
    	$this->configGroup = $config['configGroup'];
    	$this->configCode = $config['configCode'];
        $this->configKey = $config['configKey'];
        $this->scartVersion = $config['scartVersion'] ?? [];
        //Path
        $this->pathPlugin = $this->configGroup . '/' . $this->configCode . '/' . $this->configKey;
        //Language
        $this->title = trans($this->pathPlugin.'::lang.title');
        //Image logo or thumb
        $this->image = $this->pathPlugin.'/'.$config['image'];
        //
        $this->version = $config['version'];
        $this->auth = $config['auth'];
        $this->link = $config['link'];
    }

    public function install()
    {
        $return = ['error' => 0, 'msg' => ''];

        $checkMultiStore = AdminConfig::where('key', 'MultiStorePro')->first();
        if ($checkMultiStore) {
            //Check plugin multi-store exist
            return ['error' => 1, 'msg' =>  sc_language_render('plugin.plugin_action.plugin_exist')];
        }
        
        $check = AdminConfig::where('key', $this->configKey)->first();
        if ($check) {
            //Check multi-vendor  exist
            $return = ['error' => 1, 'msg' =>  sc_language_render('plugin.plugin_action.plugin_exist')];
        } else {
            //Insert plugin to config
            $dataInsert = [
                [
                    'group'  => $this->configGroup,
                    'code'   => $this->configCode,
                    'key'    => $this->configKey,
                    'sort'   => 0,
                    'value'  => self::ON, //Enable extension
                    'detail' => $this->pathPlugin.'::lang.title',
                ],
                [
                    'group'  => '',
                    'code'   => $this->configKey.'_config',
                    'key'    => 'domain_strict',
                    'sort'   => 0,
                    'value'  => 0,
                    'detail' => $this->pathPlugin.'::lang.config.domain_strict',
                ],
                [
                    'group'  => '',
                    'code'   => $this->configKey.'_config',
                    'key'    => 'vendor_allow_register',
                    'sort'   => 0,
                    'value'  => 1,
                    'detail' => 'multi_vendor.vendor_allow_register',
                ],
            ];
            
            try {
                $process = AdminConfig::insertOrIgnore(
                    $dataInsert
                );

                $idBlock = AdminMenu::insertGetId(
                    [
                        'parent_id' => 0,
                        'sort'      => 250,
                        'title'     => sc_language_render('multi_vendor.plugin_block'),
                        'icon'      => 'nav-icon fab fa-shopify',
                        'key'       => 'ADMIN_MVENDOR_SETTING',
                    ]
                );

                AdminMenu::insert(
                    [
                        'parent_id' => $idBlock,
                        'sort'      => 1,
                        'title'     => sc_language_render('multi_vendor.store_list'),
                        'icon'      => 'fas fa-h-square',
                        'uri'       => 'admin::MultiVendorPro/store'
                    ]
                );

                AdminMenu::insert(
                    [
                        'parent_id' => $idBlock,
                        'sort'      => 2,
                        'title'     => sc_language_render('multi_vendor.vendor_list'),
                        'icon'      => 'fa fa-user-circle',
                        'uri'       => 'admin::MultiVendorPro/vendor'
                    ]
                );

                $dataLang = [
                    ['code' => 'multi_vendor.plugin_block', 'text' => 'MARKETPLACE (<span style="color:red">Pro</span>)', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.plugin_block', 'text' => 'CHỢ BÁN HÀNG (<span style="color:red">Pro</span>)', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.account_inactive_title', 'text' => 'Access denied!', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.account_inactive_title', 'text' => 'Truy cập bị từ chối', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.account_inactive_msg', 'text' => 'The account has not been activated or has been locked!', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.account_inactive_msg', 'text' => 'Tài khoản chưa được kích hoạt hoặc đã bị khóa!', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.update_info_store_msg', 'text' => 'Please update your store information!', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.update_info_store_msg', 'text' => 'Vui lòng cập nhật thông tin cửa hàng của bạn!', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.update_info_store_title', 'text' => 'Update store information', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.update_info_store_title', 'text' => 'Cập nhật thông tin cửa hàng', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.store_list', 'text' => 'Store list', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.store_list', 'text' => 'Hệ thống cửa hàng', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.vendor_list', 'text' => 'Vendor list', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.vendor_list', 'text' => 'Danh sách người bán', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.vendor_add', 'text' => 'Add new vendor', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.vendor_add', 'text' => 'Thêm người bán', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.config', 'text' => 'Config information', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.config', 'text' => 'Thông tin cấu hình', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.vendor_search_place', 'text' => 'Search name, email vendor', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.vendor_search_place', 'text' => 'Tìm kiếm tên, email', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.password', 'text' => 'Password', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.password', 'text' => 'Mật khẩu', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.password_forgot', 'text' => 'Forgot password', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.password_forgot', 'text' => 'Quên mật khẩu', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.login_title', 'text' => 'Login page', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.login_title', 'text' => 'Trang đăng nhập', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.register_success', 'text' => 'Successful register', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.register_success', 'text' => 'Đăng ký thành công', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.signup', 'text' => 'Signup', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.signup', 'text' => 'Đăng ký', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.title_register', 'text' => 'Account register', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.title_register', 'text' => 'Đăng ký tài khoản', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.password_reset', 'text' => 'Password reset', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.password_reset', 'text' => 'Reset mật khẩu', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.password_confirm', 'text' => 'Password confirm', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.password_confirm', 'text' => 'Xác nhận mật khẩu', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.phone_regex', 'text' => 'The phone format is not correct. Length 8-14, use only 0-9 and the "-" SIGN.', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.phone_regex', 'text' => 'Số điện thoại định dạng không đúng. Chiều dài 8-14, chỉ sử dụng số 0-9 và "-"', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.country', 'text' => 'Country', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.country', 'text' => 'Quốc gia', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.address2', 'text' => 'Quận/Huyện', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.address2', 'text' => 'Address 2', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.address1', 'text' => 'Tỉnh/Thành', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.address1', 'text' => 'Address 1', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.postcode', 'text' => 'Mã bưu điện', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.postcode', 'text' => 'Post code', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.phone', 'text' => 'Phone', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.phone', 'text' => 'Điện thoại', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.name', 'text' => 'Name', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.name', 'text' => 'Tên', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.last_name', 'text' => 'Họ', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.last_name', 'text' => 'Last name', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.first_name', 'text' => 'Tên', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.first_name', 'text' => 'First name', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.email', 'text' => 'Email', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.email', 'text' => 'Email', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.title_login', 'text' => 'Login account', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.title_login', 'text' => 'Đăng nhập', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.status', 'text' => 'Trạng thái', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.status', 'text' => 'Status', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.group', 'text' => 'Nhóm', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.group', 'text' => 'Group', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.admin_login', 'text' => 'Vendor login', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.admin_login', 'text' => 'Dành cho người bán hàng', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.remember_me', 'text' => 'Remember me', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.remember_me', 'text' => 'Ghi nhớ tài khoản', 'position' => 'multi_vendor', 'location' => 'vi'],
                    ['code' => 'multi_vendor.login', 'text' => 'Login', 'position' => 'multi_vendor', 'location' => 'en'],
                    ['code' => 'multi_vendor.login', 'text' => 'Đăng nhập', 'position' => 'multi_vendor', 'location' => 'vi'],
                ];
                Languages::insertOrIgnore(
                    $dataLang
                );

                if (!$process) {
                    $return = ['error' => 1, 'msg' => sc_language_render('plugin.plugin_action.install_faild')];
                } else {
                    $return = (new PluginModel)->installExtension();
                }

            } catch(\Throwable $e) {
                $this->uninstall();
                $return = ['error' => 1, 'msg' => $e->getMessage()];
            }

        }

        return $return;
    }

    public function uninstall()
    {
        $return = ['error' => 0, 'msg' => ''];
        
        //Please delete all values inserted in the installation step
        AdminConfig::where('key', $this->configKey)->delete();
        AdminConfig::where('code', $this->configKey.'_config')->delete();

        //Delete menu
        $blockMenu = AdminMenu::where('key', 'ADMIN_MVENDOR_SETTING')->first();
        AdminMenu::where('parent_id', $blockMenu->id)->delete();
        AdminMenu::where('id', $blockMenu->id)->delete();

        AdminPermission::whereIn('slug', ['multi.vendor'])->delete();
        AdminRole::whereIn('slug', ['MultiVendorPro.seller'])->delete();
        Languages::where('position', 'multi_vendor')->delete();
        (new PluginModel)->uninstallExtension();

        return $return;
    }
    
    public function enable()
    {
        $return = ['error' => 0, 'msg' => ''];
        $process = (new AdminConfig)->where('key', $this->configKey)->update(['value' => self::ON]);
        if (!$process) {
            $return = ['error' => 1, 'msg' => 'Error enable'];
        }
        return $return;
    }

    public function disable()
    {
        $return = ['error' => 0, 'msg' => ''];
        $process = (new AdminConfig)
            ->where('key', $this->configKey)
            ->update(['value' => self::OFF]);
        if (!$process) {
            $return = ['error' => 1, 'msg' => 'Error disable'];
        }
        return $return;
    }

    public function config()
    {
        return redirect(sc_route_admin('admin_MultiVendorPro.index'));
    }

    public function getData()
    {
        $arrData = [
            'title'      => $this->title,
            'code'       => $this->configCode,
            'key'        => $this->configKey,
            'image'      => $this->image,
            'permission' => self::ALLOW,
            'version'    => $this->version,
            'auth'       => $this->auth,
            'link'       => $this->link,
            'value'      => 0, // this return need for plugin shipping
            'pathPlugin' => $this->pathPlugin
        ];

        return $arrData;
    }

    /**
     * Process after order success
     *
     * @param   [array]  $data  
     *
     */
    public function endApp($data = []) {
        //action after end app
    }
}
