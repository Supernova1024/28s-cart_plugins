<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Payment/PaypalExpress');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Payment/PaypalExpress');
    // $this->mergeConfigFrom(
    //     __DIR__.'/config.php', 'key_define_for_plugin'
    // );